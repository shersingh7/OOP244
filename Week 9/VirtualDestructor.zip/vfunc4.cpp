#include <iostream>
using namespace std;

/* 1. AN ARRAY OF POINTERS 
   2. polymorphism: dynamic (run-time) function binding 
   3. declaration of a virtual base-class member function
 */

class B {
   protected:
      int x;
   public:
      B(int k) { x=k*k; }

      ~B() { cout << "B::clean up " << x << endl; }

      virtual void f1() { cout << "B::f1::" << x << endl; }
};

class D: public B {
      char c;
   public:
      D(int j, char z): B(j) { c = z; }

      ~D() { cout << "D::clean up " << c << endl; }

      void f1() { cout << "D::f1::" << x << "<"
				   << c << ">" << endl; }

};

int main()
{
   B* pointers[3];  // an array of base-class pointers!

   pointers[0] = new B(5);
   pointers[1] = new D(7, '*');
   pointers[2] = new B(10);

   for (int k=0; k<3; k++) {

	pointers[k]->f1();

	delete pointers[k]; // an object will go out of scope!
			    // Question: How many destructors are called?
			    // Note: NOT delete [] pointers[k]!

   }

   cout << "....... NO MORE OBJECTS WILL GO OUT OF SCOPE ........" << endl;
   return 0;
}







