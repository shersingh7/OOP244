// StudentP.h

 #define N 30
 #define M 13
 #include "iPerson.h"

 class Person : public iPerson {
     char person[N+1];
   public:
     Person();
     Person(const char*);
     void display(std::ostream&) const; // virtual function already!!! 
 };

 class StudentP : public Person {
     int no;
     char grade[M+1];
   public:
     StudentP();
     StudentP(const char*, int, const char*); 
     void display(std::ostream&) const; // virtual function already!!!
 };
