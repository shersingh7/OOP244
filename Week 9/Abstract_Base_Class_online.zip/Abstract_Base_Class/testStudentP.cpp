// testStudentP.cpp

#include "StudentP.h"
#include <iostream>

int main(){

    StudentP a("Peter Liu", 2345, "FFFF" );
	
    a.display(std::cout);

    return 0;
}
