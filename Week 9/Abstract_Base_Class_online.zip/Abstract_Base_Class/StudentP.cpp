// StudentP.cpp

 #include "StudentP.h"
 
 #include <cstring>
 using namespace std;

 // implementation of the Person class
 Person::Person() { strcpy( person, "John Doe" ); }
 
 Person::Person(const char* s) { if (strlen(s) <= N)
				     strcpy(person, s);
				 else strcpy(person, "TOO LONG"); }
								 
 void Person::display(std::ostream& os) const{
      os << "name: " << person << endl;
} 

 // implementation of the StudentP class
 StudentP::StudentP(): Person() { no = 1111; strcpy( grade, "A"); }
 
 StudentP::StudentP(const char* ns, int number, const char* g): Person(ns){
    no = number;
    strcpy(grade, g);
 }
 
 void StudentP::display(std::ostream& os2) const{
      Person::display(os2);
	  os2 << "student number: " << no << endl
	      << "grades: " << grade << endl;
 }
 
