 // Abstract Base Class for the Person Hierarchy 
 // iPerson.h

 /* Definitions
    1. abstract base class: a class that contains or inherits a pure virtual function
    2. interface: an abstract base class that does not contain data members
  */

 #include <iostream>

 class iPerson {
   public:
     virtual void display(std::ostream&) const = 0; // not implemented 
 };
