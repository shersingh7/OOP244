// polymorphism

#include "StudentP.h"
#include <iostream>

void showPerson(iPerson*);

int main(){

    // POLYMORPHISM IN ACTION

    iPerson * ptrPerson;  // type of the pointer: Abstract Base Class/Interface

    ptrPerson = new Person( "Mary Ryan" );
    showPerson( ptrPerson );

    ptrPerson = new StudentP( "Peter Liu", 2345, "FFFF");
    showPerson( ptrPerson);

    ptrPerson = new StudentP( "Van Gogh", 7799, "????" );    
    showPerson( ptrPerson );

    return 0;

    // Tuan's question (Fall 2019): Any memory leak?
}

// a polymorphic function
void showPerson( iPerson* ptr ) {

     ptr->display(std::cout);   // polymorphic code!
				// the type of the OBJECT
}


















