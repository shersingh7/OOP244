
class Box {
   char symbol;
   int length;
   int width;

   public:
      Box();
      Box(char, int, int);

      void set(char, int, int);
      void set(int, int);
      void set(char, int);
      void set(char);

      void setLength(int);
      void setWidth(int);
      void setSymbol(char);

      char getSymbol();       // access functions
      int  getLength();
      int  getWidth();
		   
      Box  enlarge(int deltaL, int deltaW);

      void showBox(int);
};



