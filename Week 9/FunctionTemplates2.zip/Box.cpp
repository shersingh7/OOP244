
#include "Box.h"
#include <iostream>
using namespace std;


// ***** IMPLEMENTATION OF THE CLASS *****

Box::Box()
{ set(1,1); }

Box::Box(char c, int lg, int wd)
{ set(c, lg, wd); }

// access functions
char Box::getSymbol()
{
	return symbol;
}

int Box::getLength()
{
	return length;
}

int Box::getWidth()
{
	return width;
}

void Box::setSymbol(char c)
{
	symbol = c;
}

void Box::setLength(int j)
{
	length = j;
}

void Box::setWidth(int w)
{
	width = w;
}

void Box::showBox(int m)
{
	for(int i=0; i<width; i++) {
	   for (int k=0; k<m; k++) 
		    cout << " ";

	   for(int j=0; j<length; j++) 
		   cout << symbol;
	   cout << "\n";
	}
}

void Box::set(char c, int lg, int w)
{
   symbol = c;
   length = lg;
   width = w;
}

void Box::set(int lg, int w)
{
   symbol = '*';   // default

   length = lg;
   width = w;

   // set( '*', lg, w );
}

void Box::set(char c)
{
   symbol = c;

   // default values
   length = 1;
   width = 1;

  // set( c, 1, 1 );
}

Box  Box::enlarge(int deltaL, int deltaW) // the current object is NOT changed!
{
   Box local;

   local.symbol = symbol;
   local.length = length + deltaL;
   local.width  = width + deltaW;
   return local;
}
