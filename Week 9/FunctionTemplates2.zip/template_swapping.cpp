
/* 1. Function Template
      - separation of logic from data types

   2. How does the compiler process a fucntion template?
   3. The template is part of the .cpp file (not .h file)!

   updated on 5/19/2020
 */

#include <iostream>
using namespace std;

// a function template

template<typename T>
void swapping(T& t1, T& t2){

   T temp;

   temp = t1;
   t1 = t2;
   t2 = temp;
}

int main(){

    int    a=100, b=-999;
    double x=1.1, y=-9.9;
    char   c1='A', c2='z';

    /* Part 1 */
    cout << "a: " << a << " b: " << b << endl;
    
    swapping(a, b);     // 1. data types of a and b: int

    cout << "a: " << a << " b: " << b << endl;
    
    //swapping(a, y);       // What is going to happen?

    /* Part 2 */
    cout << "x: " << x << " y: " << y << endl;

    swapping(x, y);     // 2. data types of x and y: double

    cout << "x: " << x << " y: " << y << endl;

    /* Part 3 */
    cout << "c1: " << c1 << " c2: " << c2 << endl;
    
    swapping(c1, c2);   // 3. data types of c1 and c2: char

    cout << "c1: " << c1 << " c2: " << c2 << endl;
    return 0;
}











