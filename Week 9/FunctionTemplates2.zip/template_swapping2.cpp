
/* 1. Function Template
      - separation of logic from data types

   2. How does the compiler process a fucntion template?
   3. The template is part of the .cpp file (not .h file)!

   updated on 7/20/2020
 */

#include "Box.h"
#include <iostream>
using namespace std;

// a function template

template<typename T>
void swapping(T& t1, T& t2){

   T temp;

   temp = t1;
   t1 = t2;
   t2 = temp;
}

int main(){

    /* Part 4: Swap two objects! */
    Box small('*',3,5), medium('#',12,6);

    small.showBox(1);
    medium.showBox(1);

    swapping(small, medium);

    small.showBox(3);
    medium.showBox(3);
    return 0;
}











